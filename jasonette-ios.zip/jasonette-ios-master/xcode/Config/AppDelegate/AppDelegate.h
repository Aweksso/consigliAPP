//
//  AppDelegate.h
//  Jasonette
//
//  Created by Jasonelle Team on 05-07-19.
//  Copyright © 2019 Jasonette.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>
    @property (strong, nonatomic) UIWindow * window;
@end

NS_ASSUME_NONNULL_END
