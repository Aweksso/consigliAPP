//
//  JasonGeoAction.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonAction.h"
#import "INTULocationManager.h"
@interface JasonGeoAction : JasonAction<UINavigationControllerDelegate>
@end
