//
//  JasonGlobalAction.h
//  Jasonette
//
//  Created by e on 6/18/17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import "JasonAction.h"
#import "JasonHelper.h"

@interface JasonGlobalAction : JasonAction

@end
