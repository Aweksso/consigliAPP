//
//  JasonTimerAction.h
//  Jasonette
//
//  Copyright © 2016 seletz. All rights reserved.
//
#import "JasonAction.h"
@interface JasonLogAction : JasonAction
@end
