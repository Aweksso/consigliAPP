//
//  JasonReturnAction.h
//  Jasonette
//
//  Created by e on 1/4/17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import "JasonAction.h"

@interface JasonReturnAction : JasonAction

@end
