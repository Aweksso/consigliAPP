//
//  NoPaddingButton.h
//  Jasonette
//
//  Created by e on 4/7/17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoPaddingButton : UIButton

@end
