//
//  JasonAction.m
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import "JasonAction.h"
#import "JasonLogger.h"
@implementation JasonAction
- (void)initialize:(NSDictionary *)launchOptions
{
    DTLogDebug (@"initialize");
}

@end
