//
//  JasonPushService.h
//  Jasonette
//
//  Created by e on 8/25/17.
//  Copyright © 2017 Jasonette. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UserNotifications/UserNotifications.h>
#import "Jason.h"
@interface JasonPushService : NSObject  <UNUserNotificationCenterDelegate>

@end
