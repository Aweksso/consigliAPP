//
//  JasonHorizontalSectionItem.h
//  Jasonette
//
//  Copyright © 2016 gliechtenstein. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface JasonHorizontalSectionItem : UICollectionViewCell

@end
